1. Steven Liao, 918615690
2. 
Q1. 
Implement run function using dot product
Implement get_prediction function using if else statement depending on result for run
Implement train function by
	looping through dataset
	checking if prediction is correct
	if not then update weights using x as direction and y as multiplier
	run train function again if weights was changed

3. 2 hrs