1. Steven Liao 918615690
2.	1. Return a add b
   	2. Loop through tuple to do the following on every order. Deconstruct order into fruit and numPounds. Use fruit to get price from fruitPrices. Multiple price by numPounds to get cost. Add cost to totalCost. Return totalCost.
	3. Initialize bestShop to null and cheapPrice to max num. Loop through fruitShops to get every fruitShop. Use getPriceOfOrder function to get totalCost for order. Check if totalCost less than cheapestPrice. If yes, set cheapestPrice to totalCost and bestShop to fruitShop. Return bestShop.